$(function(){
	$(".radio-uniform").uniform();	
});
