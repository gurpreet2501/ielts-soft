<ul class="nav navbar-nav side-nav">
    <li class="">
      <a href='<?=site_url('/customerDashboard/index')?>'>Home</a> 
    </li>
    <li class="">
      <a href='<?=site_url('student/add_student')?>'>Student Section</a> 
    </li>
    <li class="">
      <a href='<?=site_url('student/courses')?>'>Add Course</a> 
    </li>
    <li class="">
      <a href='<?=site_url('fees/payment_selection')?>'>Fees Payment</a> 
    </li>
    <li class="">
      <a href='<?=site_url('student/bulk_sms')?>'>Bulk Sms</a> 
    </li>
  </ul>

