<?php $this->load->view('admin/partials/header'); ?>
<div class="row">
	<div class="col-xs-12">
		<h1 class="text-center">IELTS SOFTWARE</h1>
	</div>
</div>	
<?php $this->load->view('admin/partials/footer'); ?>
