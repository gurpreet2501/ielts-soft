<ul class="nav navbar-nav">
    <li class="">
      <a href='<?=site_url('/dashboard/index')?>'>Dashboard</a> 
    </li>
    <li class="">
      <a href='<?=site_url('student/add_student')?>'>Add Student</a> 
    </li>
    <li class="">
      <a href='<?=site_url('student/courses')?>'>Add Course</a> 
    </li>
  </ul>
