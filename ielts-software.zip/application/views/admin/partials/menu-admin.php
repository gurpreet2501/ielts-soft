<ul class="nav navbar-nav">
    <li class="">
      <a href='<?=site_url('/dashboard/index')?>'>Dashboard</a> 
    </li>
    <li class="">
      <a href='<?=site_url('/data/add_user')?>'>Create Institute Login</a> 
    </li>

    </ul>
