<? $this->load->view('admin/partials/header') ?>
<div class="row">
  <div class="col-lg-12">
    <?php echo $output;  ?>
  </div>
</div>
<? $this->load->view('admin/partials/footer') ?>
