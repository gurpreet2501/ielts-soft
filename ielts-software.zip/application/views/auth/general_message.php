<?php $this->load->view('admin/partials/header'); ?>

	<div class="row">
		<div class="col-md-12">
			<div class="text-center">
				<h3><?php echo $message; ?></h3>	
			</div>
		</div>
	</div>

<?php $this->load->view('admin/partials/footer'); ?>
