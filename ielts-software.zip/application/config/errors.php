<?php 

$config['errors'] = [
	101 => 'Unable to insert in database',
];

