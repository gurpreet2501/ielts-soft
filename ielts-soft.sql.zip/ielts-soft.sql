-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 06, 2018 at 11:41 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ielts-soft`
--

-- --------------------------------------------------------

--
-- Table structure for table `assigned_cards`
--

CREATE TABLE `assigned_cards` (
  `id` int(10) UNSIGNED NOT NULL,
  `card_serial` varchar(255) NOT NULL,
  `student_id` int(11) NOT NULL,
  `machine_id` int(11) NOT NULL,
  `added_by` int(11) NOT NULL,
  `blocked` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `assigned_cards`
--

INSERT INTO `assigned_cards` (`id`, `card_serial`, `student_id`, `machine_id`, `added_by`, `blocked`, `created_at`, `updated_at`) VALUES
(1, '3456465464', 10, 3, 2, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'PATIALA', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'INDIA', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(10) UNSIGNED NOT NULL,
  `course_name` varchar(20) NOT NULL,
  `course_fees` decimal(10,2) NOT NULL,
  `course_detail` text NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_name`, `course_fees`, `course_detail`, `start_time`, `end_time`, `added_by`, `created_at`, `updated_at`) VALUES
(1, 'IELTS', '1234.00', 'Morning Batch', '14:00:00', '16:00:00', 17, '2018-07-13 19:09:06', '2018-07-13 19:09:06'),
(2, 'PTE', '15000.00', 'Afternoon Batch', '12:00:00', '16:00:00', 17, '2018-07-14 09:39:18', '2018-07-14 09:39:18'),
(3, 'IELTS Morning-Batch', '5322.00', 'Morning Batch 14 - 15', '14:00:00', '15:00:00', 17, '2018-07-16 11:01:27', '2018-07-16 11:01:27');

-- --------------------------------------------------------

--
-- Table structure for table `fees_details`
--

CREATE TABLE `fees_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `students_registration_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `fees_amount` decimal(10,2) NOT NULL,
  `fee_submission_date` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `fees_details`
--

INSERT INTO `fees_details` (`id`, `students_registration_id`, `course_id`, `fees_amount`, `fee_submission_date`, `created_at`, `updated_at`) VALUES
(1, 2, 1, '321.00', '2018-07-14 08:57:10', '2018-07-14 08:57:10', '2018-07-14 08:57:10'),
(2, 2, 1, '655.00', '2018-07-14 08:57:23', '2018-07-14 08:57:23', '2018-07-14 08:57:23'),
(3, 2, 1, '76.00', '2018-07-14 08:57:30', '2018-07-14 08:57:30', '2018-07-14 08:57:30'),
(4, 2, 2, '1234.00', '2018-07-14 21:36:57', '2018-07-14 21:36:57', '2018-07-14 21:36:57'),
(5, 2, 1, '182.00', '2018-07-14 21:37:06', '2018-07-14 21:37:06', '2018-07-14 21:37:06'),
(6, 2, 2, '4000.00', '2018-08-04 13:32:18', '2018-08-04 13:32:18', '2018-08-04 13:32:18'),
(7, 1, 1, '2344.00', '2018-09-10 08:37:35', '2018-09-10 08:37:35', '2018-09-10 08:37:35'),
(8, 3, 2, '1100.00', '2018-09-10 08:38:14', '2018-09-10 08:38:14', '2018-09-10 08:38:14'),
(9, 3, 1, '1200.00', '2018-09-10 08:44:16', '2018-09-10 08:44:16', '2018-09-10 08:44:16'),
(10, 3, 1, '342.00', '2018-09-10 13:15:10', '2018-09-10 13:15:10', '2018-09-10 13:15:10'),
(11, 3, 2, '13000.00', '2018-09-10 13:15:45', '2018-09-10 13:15:45', '2018-09-10 13:15:45'),
(12, 3, 2, '900.00', '2018-09-10 13:16:00', '2018-09-10 13:16:00', '2018-09-10 13:16:00'),
(13, 1, 1, '2000.00', '2018-09-10 13:16:35', '2018-09-10 13:16:35', '2018-09-10 13:16:35'),
(14, 1, 2, '1000.00', '2018-09-10 13:16:54', '2018-09-10 13:16:54', '2018-09-10 13:16:54'),
(15, 1, 2, '14000.00', '2018-09-10 13:17:12', '2018-09-10 13:17:12', '2018-09-10 13:17:12'),
(16, 6, 1, '1000.00', '2018-09-10 13:17:41', '2018-09-10 13:17:41', '2018-09-10 13:17:41'),
(17, 8, 3, '1000.00', '2018-09-10 15:50:56', '2018-09-10 15:50:56', '2018-09-10 15:50:56'),
(18, 8, 3, '4322.00', '2018-09-10 15:51:24', '2018-09-10 15:51:24', '2018-09-10 15:51:24'),
(19, 8, 2, '0.00', '2018-09-10 15:51:34', '2018-09-10 15:51:34', '2018-09-10 15:51:34'),
(20, 8, 2, '15000.00', '2018-09-10 15:51:47', '2018-09-10 15:51:47', '2018-09-10 15:51:47'),
(21, 9, 3, '1500.00', '2018-09-10 16:53:09', '2018-09-10 16:53:09', '2018-09-10 16:53:09'),
(22, 9, 3, '3822.00', '2018-09-10 16:53:46', '2018-09-10 16:53:46', '2018-09-10 16:53:46'),
(23, 10, 1, '2000.00', '2018-09-10 17:35:15', '2018-09-10 17:35:15', '2018-09-10 17:35:15');

-- --------------------------------------------------------

--
-- Table structure for table `file_uploads`
--

CREATE TABLE `file_uploads` (
  `id` int(11) NOT NULL,
  `file_url` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `file_uploads`
--

INSERT INTO `file_uploads` (`id`, `file_url`, `status`, `added_by`, `created_at`, `updated_at`) VALUES
(1, '5a29c-credentials.csv', 0, 17, '2018-09-10 13:44:01', '2018-09-10 13:44:01'),
(2, 'd45ec-so-kyun-visre-jin-sab-kuch-diya-.mp3', 0, 17, '2018-09-10 13:43:52', '2018-09-10 13:43:52'),
(3, '11183-custom-marker.png', 0, 17, '2018-09-10 13:48:51', '2018-09-10 13:48:51'),
(4, '4019f-credentials.csv', 0, 17, '2018-09-10 17:39:23', '2018-09-10 17:39:23');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `login` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `machines`
--

CREATE TABLE `machines` (
  `id` int(10) UNSIGNED NOT NULL,
  `machine_name` varchar(20) NOT NULL,
  `machine_serial` int(11) NOT NULL,
  `added_by` int(11) NOT NULL,
  `machine_type` enum('MASTER','SLAVE','','') NOT NULL DEFAULT 'SLAVE',
  `disabled` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `machines`
--

INSERT INTO `machines` (`id`, `machine_name`, `machine_serial`, `added_by`, `machine_type`, `disabled`, `created_at`, `updated_at`) VALUES
(1, 'acdf', 32434343, 2, 'MASTER', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_06_08_042331_add_button_status_field_in_machines_tbl', 1),
(2, '2018_06_13_154317_make_lat_long_double_fiels', 2),
(4, '2018_06_13_160445_add_lat_long_to_cust_addr_tbl', 3);

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'PUNJAB', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `students_attendence`
--

CREATE TABLE `students_attendence` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_id` int(11) NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `course_id` int(11) NOT NULL,
  `machine_id` int(100) NOT NULL,
  `card_id` varchar(100) NOT NULL,
  `attendence_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students_attendence`
--

INSERT INTO `students_attendence` (`id`, `student_id`, `added_by`, `created_at`, `updated_at`, `course_id`, `machine_id`, `card_id`, `attendence_time`) VALUES
(15, 10, 17, '2018-10-06 13:51:44', '2018-10-06 13:51:44', 2, 1, '1', '2018-10-06 13:51:44'),
(16, 10, 17, '2018-10-06 15:05:15', '2018-10-06 15:05:15', 2, 3, '1', '2018-10-06 15:05:15');

-- --------------------------------------------------------

--
-- Table structure for table `students_registration`
--

CREATE TABLE `students_registration` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_unique_code` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `profile_image` varchar(200) NOT NULL,
  `date_of_birth` date NOT NULL,
  `fathers_name` varchar(100) NOT NULL,
  `fathers_occupation` varchar(20) NOT NULL,
  `fathers_contact` int(13) NOT NULL,
  `address` varchar(500) NOT NULL,
  `city_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `zip_code` int(11) NOT NULL,
  `highest_qualification` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `registration_date` datetime NOT NULL,
  `registration_confirmation` enum('PENDING','CONFIRMED','','') NOT NULL,
  `fees_status` enum('PENDING','PAID','','') NOT NULL DEFAULT 'PENDING',
  `added_by` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students_registration`
--

INSERT INTO `students_registration` (`id`, `student_unique_code`, `name`, `email`, `phone`, `profile_image`, `date_of_birth`, `fathers_name`, `fathers_occupation`, `fathers_contact`, `address`, `city_id`, `state_id`, `country_id`, `zip_code`, `highest_qualification`, `created_at`, `updated_at`, `registration_date`, `registration_confirmation`, `fees_status`, `added_by`) VALUES
(10, 'STU10', 'Parampreet Singh69', 'param102@gmail.com', '9914836169', '', '1991-02-12', 'fsdffsfds', 'hjjgfd', 34543, 'gjhghjgj', 0, 0, 0, 354345, 'MCA', '2018-09-10 17:34:41', '2018-09-10 17:35:15', '2018-09-10 17:34:41', 'CONFIRMED', 'PAID', 17);

-- --------------------------------------------------------

--
-- Table structure for table `students_registration_courses`
--

CREATE TABLE `students_registration_courses` (
  `id` int(10) UNSIGNED NOT NULL,
  `students_registration_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students_registration_courses`
--

INSERT INTO `students_registration_courses` (`id`, `students_registration_id`, `course_id`, `created_at`, `updated_at`) VALUES
(1, 2, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 1, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 3, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 2, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 1, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 3, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 4, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 4, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 5, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 6, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 7, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 8, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 8, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 10, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 10, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tank_auth_users`
--

CREATE TABLE `tank_auth_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `device_id` text COLLATE utf8_unicode_ci NOT NULL,
  `device_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `activated` tinyint(4) NOT NULL,
  `role` enum('ADMIN','CUSTOMER','','') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'CUSTOMER',
  `banned` tinyint(4) NOT NULL,
  `ban_reason` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `new_password_key` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `new_password_requested` datetime NOT NULL,
  `new_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `new_email_key` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tank_auth_users`
--

INSERT INTO `tank_auth_users` (`id`, `username`, `password`, `email`, `phone`, `name`, `device_id`, `device_type`, `activated`, `role`, `banned`, `ban_reason`, `password_reset_token`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created_at`, `updated_at`, `modified`) VALUES
(15, 'admin', '$2a$08$WDc0qv1KxnuvO3fsuTaLVuXJbphyLAE9VxYmAzG3GZdRw2hf5N846', 'gurpreet2501@gmail.com', '9814158141', 'Amanpreet Singh', 'c2hldhi9v2c:APA91bFCwYb_gm_dCQWONq3iom1W00yVRJdo4dxWssyjAiRqBB5v3RjzH_L7U8S4BN97clgKhXGammWms4SN-l1zKlI57QxHcMjIAZsiwU4kuJikA6hMLombnxRY0_DRtAZEiSit2eAU', 'ANDROID', 1, 'ADMIN', 0, '', '', '', '0000-00-00 00:00:00', '', '', '127.0.0.1', '2018-10-06 12:12:43', '2018-06-02 16:52:53', '2018-06-02 16:52:53', '0000-00-00 00:00:00'),
(16, 'nagra', '$2a$08$xbTUwti7.Yop83kOWQltBOWWWgVnDZYbyWffTpkeyQfwxblaXOp02', 'nagra@gmail.com', '343242', '', '', '', 1, 'CUSTOMER', 0, '', '', '', '0000-00-00 00:00:00', '', '', '127.0.0.1', '2018-07-12 16:16:19', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 'zedstart', '$2a$08$TM6wqbap/8DzXBaACAl2AuAfIsvyekpahs3Tsz.Ko8VpWYbSaJBb6', 'zedstart@gmail.com', '8768768763', '', '', '', 1, 'CUSTOMER', 0, '', '', '', '0000-00-00 00:00:00', '', '', '127.0.0.1', '2018-10-06 12:12:53', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tank_auth_user_autologin`
--

CREATE TABLE `tank_auth_user_autologin` (
  `key_id` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tank_auth_user_profiles`
--

CREATE TABLE `tank_auth_user_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `country` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_sessions`
--

INSERT INTO `user_sessions` (`id`, `user_id`, `token`, `created_at`, `updated_at`) VALUES
(1, 9, '2y10XGhnREY4Ir1mSqS8thu9uyVcAgTymxHc7eRv57hi9SmFiPcMUTS', '2018-06-02 16:52:53', '2018-06-02 16:52:53'),
(2, 10, '2y10PRBOTloR869flGJWrLkR2uXIyCWabtQWGeGWZqVJXKdIl7S9rJCMy', '2018-06-06 12:10:46', '2018-06-06 12:10:46'),
(3, 11, '2y10LDkz2TH9pSPMZEtDIEcg64Z6TjgHGkljyo8lSuI5fBMff51APG', '2018-06-07 09:45:22', '2018-06-07 09:45:22'),
(4, 12, '2y1022cQmM6dWFGNmoA17viZOrn1MEwXxAcqq177H7fnb6pE0jdVbWC', '2018-06-08 07:22:29', '2018-06-08 07:22:29'),
(5, 13, '2y10QKrBwBk3lFJ8wk4w2VV7Kex1VpM8Pb1WlkzLFTlSpuXsFrnXM9yoi', '2018-06-08 07:22:57', '2018-06-08 07:22:57'),
(6, 14, '2y10KL0U34ubEaL2KrxciviIOOtwmWw4FcdqcByRLRKLeQn01JVnPy', '2018-06-13 09:02:29', '2018-06-13 09:02:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assigned_cards`
--
ALTER TABLE `assigned_cards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fees_details`
--
ALTER TABLE `fees_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `file_uploads`
--
ALTER TABLE `file_uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `machines`
--
ALTER TABLE `machines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students_attendence`
--
ALTER TABLE `students_attendence`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students_registration`
--
ALTER TABLE `students_registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students_registration_courses`
--
ALTER TABLE `students_registration_courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tank_auth_users`
--
ALTER TABLE `tank_auth_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tank_auth_user_autologin`
--
ALTER TABLE `tank_auth_user_autologin`
  ADD PRIMARY KEY (`key_id`,`user_id`);

--
-- Indexes for table `tank_auth_user_profiles`
--
ALTER TABLE `tank_auth_user_profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_sessions_user_id_unique` (`user_id`),
  ADD UNIQUE KEY `user_sessions_token_unique` (`token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assigned_cards`
--
ALTER TABLE `assigned_cards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fees_details`
--
ALTER TABLE `fees_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `file_uploads`
--
ALTER TABLE `file_uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `machines`
--
ALTER TABLE `machines`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `students_attendence`
--
ALTER TABLE `students_attendence`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `students_registration`
--
ALTER TABLE `students_registration`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `students_registration_courses`
--
ALTER TABLE `students_registration_courses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tank_auth_users`
--
ALTER TABLE `tank_auth_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tank_auth_user_profiles`
--
ALTER TABLE `tank_auth_user_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_sessions`
--
ALTER TABLE `user_sessions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
