-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2018 at 07:00 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ielts-soft`
--

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE `cities` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cities`
--

INSERT INTO `cities` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'PATIALA', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'INDIA', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` int(10) UNSIGNED NOT NULL,
  `course_name` varchar(20) NOT NULL,
  `course_fees` decimal(10,2) NOT NULL,
  `course_detail` text NOT NULL,
  `added_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `course_name`, `course_fees`, `course_detail`, `added_by`, `created_at`, `updated_at`) VALUES
(1, 'IELTS', '5000.00', 'All 4 modules', 17, '2018-07-03 17:52:59', '2018-07-03 17:52:59'),
(2, 'PTE', '4500.00', '', 17, '2018-07-03 17:53:18', '2018-07-03 17:53:18'),
(3, 'IELTS', '3500.00', '', 18, '2018-07-03 21:13:02', '2018-07-03 21:13:02'),
(4, 'Test Course', '3400.00', 'Test course to check dropdown if working fine or still showing all the courses', 18, '2018-07-03 21:29:01', '2018-07-03 21:29:01'),
(5, 'IELTS', '7500.00', '', 19, '2018-07-03 22:06:26', '2018-07-03 22:06:26');

-- --------------------------------------------------------

--
-- Table structure for table `fees_details`
--

CREATE TABLE `fees_details` (
  `id` int(10) UNSIGNED NOT NULL,
  `students_registration_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `fees_amount` decimal(10,2) NOT NULL,
  `fee_submission_date` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `ip_address` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `login` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2018_06_08_042331_add_button_status_field_in_machines_tbl', 1),
(2, '2018_06_13_154317_make_lat_long_double_fiels', 2),
(4, '2018_06_13_160445_add_lat_long_to_cust_addr_tbl', 3);

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE `states` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'PUNJAB', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `students_registration`
--

CREATE TABLE `students_registration` (
  `id` int(10) UNSIGNED NOT NULL,
  `student_unique_code` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `profile_image` varchar(200) NOT NULL,
  `date_of_birth` date NOT NULL,
  `fathers_name` varchar(100) NOT NULL,
  `fathers_occupation` varchar(20) NOT NULL,
  `fathers_contact` int(13) NOT NULL,
  `address` varchar(500) NOT NULL,
  `city_id` int(11) NOT NULL,
  `state_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `zip_code` int(11) NOT NULL,
  `highest_qualification` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `registration_date` datetime NOT NULL,
  `registration_confirmation` tinyint(1) NOT NULL,
  `added_by` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students_registration`
--

INSERT INTO `students_registration` (`id`, `student_unique_code`, `name`, `email`, `phone`, `profile_image`, `date_of_birth`, `fathers_name`, `fathers_occupation`, `fathers_contact`, `address`, `city_id`, `state_id`, `country_id`, `zip_code`, `highest_qualification`, `created_at`, `updated_at`, `registration_date`, `registration_confirmation`, `added_by`) VALUES
(2, '', 'Gurpreet Singh', 'gps@test.com', '898686234', '', '2018-07-07', 'Mpsingh', 'Businessman ', 2147483647, '<p>\r\n	Hno 4, street no4, gnn tripuri patiala</p>\r\n', 0, 0, 0, 147001, 'Mca', '2018-07-01 18:19:18', '2018-07-01 18:19:18', '2018-07-01 18:19:18', 1, 16),
(4, '', 'Dennis James', 'beji@mailinator.net', '165', '', '2018-07-19', 'Jana Morales', 'Esse asperiores qui', 0, 'Voluptate earum ut exercitation quia dolores eu', 0, 0, 0, 45292, 'Sapiente ab t', '2018-07-03 22:00:04', '2018-07-03 22:00:04', '2018-07-03 22:00:04', 1, 18),
(6, '', 'Megan Turner', 'hubuqun@mailinator.net', '219', '', '1970-01-01', 'Uma Black', 'Eum et voluptatum et', 0, 'Do at ex dolor rerum maxime', 0, 0, 0, 58028, 'Sed libero fuga Ame', '2018-07-03 22:16:42', '2018-07-03 22:16:42', '2018-07-03 22:16:42', 0, 19),
(7, '', 'Dara Beach', 'tozacuf@mailinator.net', '223', '', '1970-01-01', 'Hayley Long', 'Quaerat obcaecati vo', 0, 'Architecto sed ea ex ut aute est quisquam nihil porro quos sed', 0, 0, 0, 79220, 'Occaecat quia dolor ', '2018-07-03 22:16:52', '2018-07-03 22:16:52', '2018-07-03 22:16:52', 0, 19),
(10, 'STU10', 'Isaac Hudson', 'gurpreet.agsoft@gmail.com', '2147483647', '', '0000-00-00', 'Reagan Parks', 'Dicta voluptatibus u', 0, 'Officiis enim id optio do aut proident enim quisquam delectus lorem sint modi consequatur Ea esse ad ab', 0, 0, 0, 99961, 'Sequi enim porro nul', '2018-07-04 22:15:17', '2018-07-04 22:15:17', '2018-07-04 22:15:17', 0, 17),
(19, 'STU19', 'Sasha Smith', 'kelyropi@mailinator.net', '+298-84-3790669', '', '1970-01-01', 'Alika Mendoza', 'Veritatis et provide', 0, 'Enim modi cumque enim ea esse voluptate est aut', 0, 0, 0, 28721, 'Labore quis sunt nu', '2018-07-04 22:13:06', '2018-07-04 22:13:06', '2018-07-04 22:13:06', 0, 17),
(20, 'STU20', 'Shea Snider', 'bimerasu@mailinator.com', '+134-49-2030973', '', '2018-07-05', 'Blake Riddle', 'Cillum omnis consequ', 0, 'Similique nostrum quo culpa et ex minus ipsum consequatur dolorem doloribus quibusdam inventore magni quos', 1, 1, 1, 81372, 'Occaecat labore volu', '2018-07-04 22:28:34', '2018-07-04 22:28:34', '2018-07-04 22:28:34', 0, 17);

-- --------------------------------------------------------

--
-- Table structure for table `students_registration_courses`
--

CREATE TABLE `students_registration_courses` (
  `id` int(10) UNSIGNED NOT NULL,
  `students_registration_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students_registration_courses`
--

INSERT INTO `students_registration_courses` (`id`, `students_registration_id`, `course_id`, `created_at`, `updated_at`) VALUES
(3, 4, 3, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 4, 4, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 6, 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 7, 5, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 10, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 10, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(20, 19, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(21, 19, 2, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(22, 20, 1, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tank_auth_users`
--

CREATE TABLE `tank_auth_users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `device_id` text COLLATE utf8_unicode_ci NOT NULL,
  `device_type` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `activated` tinyint(4) NOT NULL,
  `role` enum('ADMIN','CUSTOMER','','') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'CUSTOMER',
  `banned` tinyint(4) NOT NULL,
  `ban_reason` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `new_password_key` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `new_password_requested` datetime NOT NULL,
  `new_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `new_email_key` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tank_auth_users`
--

INSERT INTO `tank_auth_users` (`id`, `username`, `password`, `email`, `phone`, `name`, `device_id`, `device_type`, `activated`, `role`, `banned`, `ban_reason`, `password_reset_token`, `new_password_key`, `new_password_requested`, `new_email`, `new_email_key`, `last_ip`, `last_login`, `created_at`, `updated_at`, `modified`) VALUES
(15, 'admin', '$2a$08$WDc0qv1KxnuvO3fsuTaLVuXJbphyLAE9VxYmAzG3GZdRw2hf5N846', 'gurpreet2501@gmail.com', '9814158141', 'Amanpreet Singh', 'c2hldhi9v2c:APA91bFCwYb_gm_dCQWONq3iom1W00yVRJdo4dxWssyjAiRqBB5v3RjzH_L7U8S4BN97clgKhXGammWms4SN-l1zKlI57QxHcMjIAZsiwU4kuJikA6hMLombnxRY0_DRtAZEiSit2eAU', 'ANDROID', 1, 'ADMIN', 0, '', '', '', '0000-00-00 00:00:00', '', '', '127.0.0.1', '2018-07-04 22:28:14', '2018-06-02 16:52:53', '2018-06-02 16:52:53', '0000-00-00 00:00:00'),
(16, 'qomyha', '$2a$08$rGvx74FpjjipdQZwS.tCue.RfyZI2xyuCRAsa89LoXVDAoydMkhMi', 'qyzinexyli@mailinator.net', '+962-11-7360683', '', '', '', 1, 'CUSTOMER', 0, '', '', '', '0000-00-00 00:00:00', '', '', '127.0.0.1', '2018-06-30 17:20:43', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 'sophia', '$2a$08$0x0LlaAUzaVFNhPafSTZpOmihcMEzf3um1OrmuYqKBenhm4uxxH6K', 'sophia@gmail.com', '9876738723', '', '', '', 1, 'CUSTOMER', 0, '', '', '', '0000-00-00 00:00:00', '', '', '127.0.0.1', '2018-07-04 22:28:26', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 'zedstart', '$2a$08$NeeRxeFWcuan1DIJ9SeNuulbK2aBp6IilED7QIfJVgUKb6xxn6o1K', 'test@gmail.com', '868768723', '', '', '', 1, 'CUSTOMER', 0, '', '', '', '0000-00-00 00:00:00', '', '', '127.0.0.1', '2018-07-04 22:16:04', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 'aman', '$2a$08$estflSsDbsdGi5uRd/oGUOJTFntWnfXV2ORB1S7FZswvVjM3cUaPC', 'aman@gmail.com', '7696219782', '', '', '', 1, 'CUSTOMER', 0, '', '', '', '0000-00-00 00:00:00', '', '', '127.0.0.1', '2018-07-03 22:14:45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tank_auth_user_autologin`
--

CREATE TABLE `tank_auth_user_autologin` (
  `key_id` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_agent` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `last_ip` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tank_auth_user_profiles`
--

CREATE TABLE `tank_auth_user_profiles` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `country` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_sessions`
--

CREATE TABLE `user_sessions` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_sessions`
--

INSERT INTO `user_sessions` (`id`, `user_id`, `token`, `created_at`, `updated_at`) VALUES
(1, 9, '2y10XGhnREY4Ir1mSqS8thu9uyVcAgTymxHc7eRv57hi9SmFiPcMUTS', '2018-06-02 16:52:53', '2018-06-02 16:52:53'),
(2, 10, '2y10PRBOTloR869flGJWrLkR2uXIyCWabtQWGeGWZqVJXKdIl7S9rJCMy', '2018-06-06 12:10:46', '2018-06-06 12:10:46'),
(3, 11, '2y10LDkz2TH9pSPMZEtDIEcg64Z6TjgHGkljyo8lSuI5fBMff51APG', '2018-06-07 09:45:22', '2018-06-07 09:45:22'),
(4, 12, '2y1022cQmM6dWFGNmoA17viZOrn1MEwXxAcqq177H7fnb6pE0jdVbWC', '2018-06-08 07:22:29', '2018-06-08 07:22:29'),
(5, 13, '2y10QKrBwBk3lFJ8wk4w2VV7Kex1VpM8Pb1WlkzLFTlSpuXsFrnXM9yoi', '2018-06-08 07:22:57', '2018-06-08 07:22:57'),
(6, 14, '2y10KL0U34ubEaL2KrxciviIOOtwmWw4FcdqcByRLRKLeQn01JVnPy', '2018-06-13 09:02:29', '2018-06-13 09:02:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cities`
--
ALTER TABLE `cities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `countries`
--
ALTER TABLE `countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fees_details`
--
ALTER TABLE `fees_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students_registration`
--
ALTER TABLE `students_registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students_registration_courses`
--
ALTER TABLE `students_registration_courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tank_auth_users`
--
ALTER TABLE `tank_auth_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tank_auth_user_autologin`
--
ALTER TABLE `tank_auth_user_autologin`
  ADD PRIMARY KEY (`key_id`,`user_id`);

--
-- Indexes for table `tank_auth_user_profiles`
--
ALTER TABLE `tank_auth_user_profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_sessions`
--
ALTER TABLE `user_sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user_sessions_user_id_unique` (`user_id`),
  ADD UNIQUE KEY `user_sessions_token_unique` (`token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cities`
--
ALTER TABLE `cities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `countries`
--
ALTER TABLE `countries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `fees_details`
--
ALTER TABLE `fees_details`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `states`
--
ALTER TABLE `states`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `students_registration`
--
ALTER TABLE `students_registration`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `students_registration_courses`
--
ALTER TABLE `students_registration_courses`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tank_auth_users`
--
ALTER TABLE `tank_auth_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tank_auth_user_profiles`
--
ALTER TABLE `tank_auth_user_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_sessions`
--
ALTER TABLE `user_sessions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
